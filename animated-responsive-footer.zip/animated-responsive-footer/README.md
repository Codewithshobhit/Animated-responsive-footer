# Animated responsive footer

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/WNmwdVy](https://codepen.io/Codewithshobhit/pen/WNmwdVy).

